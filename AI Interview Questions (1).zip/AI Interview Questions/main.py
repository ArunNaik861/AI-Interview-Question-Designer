from task import InterviewTask
import time


def print_header():

    print("\n")
    print("╔" + "═" * 58 + "╗")
    print("║" + " AI INTERVIEW QUESTION DESIGNER ".center(58) + "║")
    print("║" + " Powered by AI ".center(58) + "║")
    print("╚" + "═" * 58 + "╝")
    print()


def loading():

    print("🤖 AI is generating interview questions", end="")

    for i in range(3):
        time.sleep(0.5)
        print(".", end="")

    print("\n")


def main():

    print_header()

    role = input("💼 Enter Job Role        : ")

    experience = input("📈 Enter Experience Level: ")


    print("\n" + "-" * 60)

    loading()


    try:

        task = InterviewTask()

        result = task.run(
            role,
            experience
        )


        print("=" * 60)

        print("📄 GENERATED INTERVIEW QUESTIONS")

        print("=" * 60)


        print(result)


        print("\n" + "=" * 60)

        print("✅ Interview Questions Generated Successfully")

        print("=" * 60)


    except Exception as e:

        print("\n❌ Error:")
        print(e)



if __name__ == "__main__":
    main()