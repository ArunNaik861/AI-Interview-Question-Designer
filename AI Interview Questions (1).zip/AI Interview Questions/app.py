import streamlit as st
from task import InterviewTask


# -----------------------------------
# Page Configuration
# -----------------------------------

st.set_page_config(
    page_title="AI Interview Question Designer",
    page_icon="🤖",
    layout="wide"
)


# -----------------------------------
# Custom CSS
# -----------------------------------

st.markdown("""
<style>

#MainMenu {visibility:hidden;}
footer {visibility:hidden;}
header {visibility:hidden;}


.stApp{

background:
radial-gradient(circle at top left,#4338ca 0%,transparent 40%),
radial-gradient(circle at bottom right,#06b6d4 0%,transparent 40%),
linear-gradient(135deg,#020617,#111827,#1e293b);

}


/* Hero */

.hero{

text-align:center;
padding:40px 20px;

}


.hero h1{

font-size:52px;
font-weight:900;

background:
linear-gradient(
90deg,
#38bdf8,
#818cf8,
#c084fc
);

-webkit-background-clip:text;
-webkit-text-fill-color:transparent;

}


.hero p{

font-size:20px;
color:#d1d5db;

}



/* Job Role Input */


.stTextInput > div > div > input{

height:75px;

font-size:22px;

padding-left:25px;

border-radius:25px;

background:#111827;

color:white;

border:3px solid #38bdf8;

box-shadow:
0 10px 25px
rgba(56,189,248,.25);

}



.stTextInput input::placeholder{

color:#94a3b8;

font-size:18px;

}



/* Labels */


.stTextInput label,
.stSelectbox label{

font-size:22px;

font-weight:700;

color:#38bdf8;

}



/* Dropdown */


.stSelectbox div[data-baseweb="select"]{

height:75px;

border-radius:25px;

font-size:20px;

}



/* Generate Button */


.stButton button{

height:65px;

width:100%;

border-radius:20px;

font-size:22px;

font-weight:bold;

background:

linear-gradient(
90deg,
#2563eb,
#7c3aed
);

color:white;

}



.stButton button:hover{

transform:translateY(-5px);

}



/* Result */


.result{

background:white;

padding:30px;

border-radius:20px;

color:#111827;

margin-top:30px;

box-shadow:
0 15px 40px
rgba(0,0,0,.35);

}


</style>

""", unsafe_allow_html=True)



# -----------------------------------
# Header
# -----------------------------------

st.markdown("""
<div class="hero">

<h1>
🤖 AI Interview Question Designer
</h1>

<p>
Generate professional interview questions with AI answers
</p>

</div>

""", unsafe_allow_html=True)



# -----------------------------------
# Input Section
# -----------------------------------

col1,col2 = st.columns([2,1])


with col1:

    role = st.text_input(
        "💼 Job Role",
        placeholder=
        "Python Developer, AI Engineer, Data Scientist..."
    )



with col2:

    experience = st.selectbox(
        "📈 Experience Level",
        [
            "Fresher",
            "1 Year",
            "2 Years",
            "3 Years",
            "5 Years",
            "8+ Years"
        ]
    )



st.write("")



generate = st.button(
    "🚀 Generate Interview Questions & Answers"
)



# -----------------------------------
# Generate
# -----------------------------------

if generate:


    if role.strip()=="":


        st.warning(
            "Please enter a job role"
        )


    else:


        try:


            with st.spinner(
                "🤖 AI is preparing questions..."
            ):


                task = InterviewTask()


                result = task.run(
                    role,
                    experience
                )



            st.success(
                "Questions Generated Successfully!"
            )



            st.markdown(
                """
                <div class="result">

                <h2>
                📄 Interview Questions & Answers
                </h2>

                </div>
                """,
                unsafe_allow_html=True
            )



            st.markdown(result)



            st.download_button(

                label=
                "📥 Download Questions & Answers",

                data=result,

                file_name=
                "AI_Interview_Questions_Answers.txt",

                mime=
                "text/plain"

            )



        except Exception as e:


            st.error(
                f"❌ Error : {e}"
            )