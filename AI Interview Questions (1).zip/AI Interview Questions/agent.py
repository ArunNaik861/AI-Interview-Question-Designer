import os
from dotenv import load_dotenv
from openai import OpenAI

# Load .env file
load_dotenv()

API_KEY = os.getenv("OPENAI_API_KEY")   # <-- Must match your .env

print("API Key Loaded:", API_KEY is not None)

if not API_KEY:
    raise ValueError("OPENAI_API_KEY not found.")

client = OpenAI(
    api_key=API_KEY,
    base_url="https://openrouter.ai/api/v1"
)

MODEL = "openai/gpt-4o-mini"


class InterviewQuestionAgent:

    def generate_questions(self, role, experience):

        prompt = f"""
Generate 20 interview questions.

Role: {role}
Experience: {experience}
"""

        response = client.chat.completions.create(
            model=MODEL,
            messages=[
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        )

        return response.choices[0].message.content