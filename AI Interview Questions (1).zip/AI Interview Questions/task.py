import os

from dotenv import load_dotenv

from openai import OpenAI



load_dotenv()



client = OpenAI(

    api_key=os.getenv(
        "OPENROUTER_API_KEY"
    ),

    base_url=
    "https://openrouter.ai/api/v1"

)



class InterviewTask:


    def __init__(self):

        self.model = (
            "openai/gpt-4o-mini"
        )



    def run(
        self,
        role,
        experience
    ):


        prompt = f"""

You are a senior technical interviewer
and hiring manager.


Create an interview preparation document.



Candidate Role:

{role}



Experience Level:

{experience}



Generate 15 interview questions
with answers.



Use different question types:



1. Concept Questions

2. Scenario Based Questions

3. Problem Solving Questions

4. Coding Questions

5. Technical Deep Dive Questions

6. Project Based Questions

7. System Design Questions



Follow this format:



================================================


📌 Question 1


Category:

(Concept / Scenario / Coding / Design / Project)



Question:

Write the interview question.



✅ Answer:


Give a detailed professional answer.

Explain:

- Definition
- Working
- Practical example



⭐ Interview Evaluation:


Explain what a good candidate should mention.



================================================



Rules:


- Questions must be unique.
- Avoid repeated topics.
- Answers must be accurate.
- Make difficulty suitable for {experience}.
- Use industry-level examples.



"""



        response = client.chat.completions.create(


            model=self.model,


            messages=[


                {

                "role":"system",

                "content":
                "You are an expert AI interview assistant."

                },


                {

                "role":"user",

                "content":prompt

                }

            ],


            temperature=0.7

        )



        return response.choices[0].message.content